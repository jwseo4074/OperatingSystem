//readcount.c 가 잘 돌아가나 확인

#include "types.h"
#include "stat.h"
#include "user.h"

// getreadcount 함수를 불러주자 => return 값은 분명히 int 일거야
int main(int argc, char *argv[]) {
  printf(1, "How many count system call (read()) => %d\n", getreadcount());
  exit();
}
